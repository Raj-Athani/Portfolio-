This is my personal blog. Feel free to visit :)
